//
//  MainViewController.h
//
//  Created by Sergey Tkachenko on 2/6/14.
//  Copyright © 2014 Progress Software Corporation.  All Rights Reserved.
//

#import <Cordova/CDVViewController.h>

@interface MainViewController : CDVViewController

@end
