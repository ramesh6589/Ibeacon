AppConfigProcessor = function ( )  {
    
        if (typeof appconfig == 'object') { 
           
            if (SessionService_Session.serviceSettings.serviceURI === "")
                SessionService_Session.serviceSettings.serviceURI = (appconfig.serviceURI!==undefined)?appconfig.serviceURI:"";
          
            if (SessionService_Session.serviceSettings.catalogURIs === "")      
                SessionService_Session.serviceSettings.catalogURIs = (appconfig.catalogURIs!==undefined)?appconfig.catalogURIs:"";

            if (SessionService_Session.serviceSettings.authenticationModel.toUpperCase() === "ANONYMOUS")
                SessionService_Session.serviceSettings.authenticationModel = (appconfig.authenticationModel!==undefined)?appconfig.authenticationModel:"ANONYMOUS";

        }
    
};