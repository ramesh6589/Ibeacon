/*
 * Service settings
 */
var SessionService_Settings = {
    "serviceURI": "",
    "catalogURIs": "",
    "authenticationModel": "ANONYMOUS",
    "authenticationResource": ""
};
var RB_beacon_Service_beacon_Settings = {
    "resourceName": "beacon",
    "autoSave": "true"
};

/*
 * Session services
 */
/* JSDO Session service */

var SessionService_Session = new Appery.Session({
    'serviceSettings': SessionService_Settings
});

/* JSDO Session login */

var SessionService_Login = new Appery.SessionLogin({
    'service': SessionService_Session
});

/* JSDO Session logout */

var SessionService_Logout = new Appery.SessionLogout({
    'service': SessionService_Session

});

/*
 * Services
 */
RB_beacon_Service_beacon_JSDO = new Appery.JSDO({

    'serviceSettings': RB_beacon_Service_beacon_Settings
});
RB_beacon_Service_beacon_beacon_Update = new Appery.JSDOUpdate({

    'service': RB_beacon_Service_beacon_JSDO,
    'tableName': 'beacon'
});
RB_beacon_Service_beacon_beacon_Delete = new Appery.JSDODelete({

    'service': RB_beacon_Service_beacon_JSDO,
    'tableName': 'beacon'
});
RB_beacon_Service_beacon_beacon_Create = new Appery.JSDOCreate({

    'service': RB_beacon_Service_beacon_JSDO,
    'tableName': 'beacon'
});
RB_beacon_Service_beacon_beacon_Row = new Appery.JSDORow({

    'service': RB_beacon_Service_beacon_JSDO,
    'tableName': 'beacon'
});
RB_beacon_Service_beacon_getView_All_beacons = new Appery.JSDOInvoke({

    'service': RB_beacon_Service_beacon_JSDO,
    'methodName': 'getView_All_beacons',
    'tableName': 'beacon'
});
RB_beacon_Service_beacon_Read = new Appery.JSDORead({

    'service': RB_beacon_Service_beacon_JSDO,
    'tableName': 'beacon'
});

var RESTService1 = new Appery.RestService({
    'url': '',
    'dataType': 'json',
    'type': 'get',
});