var on = new Object();
var ipaddress = "172.21.75.161";
var sessionid;
var loginName = "ibeacon";
var password = "Progress123";

function createBeacon(uuid, identifier) {
    var minor = 3333; // optional, defaults to wildcard if left empty
    var major = 1000; // optional, defaults to wildcard if left empty
    var beaconRegion = new locationManager.locationManager.BeaconRegion(identifier, uuid, major, minor);
    return beaconRegion;
}

function initial() {
    //alert("initial");
    var delegate = new locationManager.locationManager.Delegate().implement({
        didDetermineStateForRegion: function(pluginResult) {
           // alert("Determined");
            //logToDom('[DOM] didDetermineStateForRegion: ' + JSON.stringify(pluginResult));
            locationManager.locationManager.appendToDeviceLog('[DOM] didDetermineStateForRegion: ' + JSON.stringify(pluginResult));
        },
        
        didStartMonitoringForRegion: function(pluginResult) {
           // alert("Monitoring");
            console.log('didStartMonitoringForRegion:', pluginResult);
            //  logToDom('didStartMonitoringForRegion:' + JSON.stringify(pluginResult));
        },
        
        didRangeBeaconsInRegion: function(pluginResult) {
    
            rangeresponse = JSON.parse(JSON.stringify(pluginResult));
    //alert(rangeresponse);
            var uuid = rangeresponse["region"]["uuid"].toUpperCase();
      //   alert(uuid);
            var identifier = rangeresponse["region"]["identifier"];
        //    alert(identifier);
            var distance = rangeresponse["beacons"][0]["proximity"];
         // alert(distance);
            var rssi = rangeresponse["beacons"][0]["rssi"];
           if(distance.toUpperCase() == String("proximityNear").toUpperCase()) {
					if (on[uuid] == 0) {
						on[uuid] = 1;
						//alert(uuid);
                        $.ajax({
                            url: "https://www.rollbase.com/rest/api/selectQuery?query=select beaconmessage from beacon where beaconuid='"+uuid+"'&loginName=ram1023&password=Progress123&custId=106603520",
                            type: 'GET',
                            dataType: 'html',
                           
                            success: function(data, textStatus, xhr) {
                          start = data.indexOf("<col>") + 5;
    									end = data.indexOf("</col>");
    									var data1 = data.substring(start,end);
                                alert(data1);
                                
                            },
                            error: function(xhr, textStatus, errorThrown) {
                               alert('error');
                            }
                        });
						
					}
				} else if (distance.toUpperCase() == String("proximityFar").toUpperCase()) {
					if (on[uuid] == 1) {
						on[uuid] = 0;
                        //alert("far");
						//document.getElementById("MRegion").innerHTML = "Far "+uuid;
						//$("#MRegion").append("Far -> " + uuid + "<br>");
					}
				}
            //locationManager.locationManager.stopRangingBeaconsInRegion(createBeacon(uuid, identifier));
        }
    });
    locationManager.locationManager.setDelegate(delegate);
}

function Master() {
   // alert("Master");
    var uuids = new Array();
    var identifiers = new Array();
    var beaconRegion = new Array();
    //alert("beacon");
    uuids.push('86C7185B-6A99-4A38-86E4-859CA3E742A7');
    uuids.push('F7028248-68B4-4F65-8087-D5D5CB3A1CBD');
    for (var i = 0; i < uuids.length; i++) {
        on[uuids[i]] = 0;
    }
     initial();
    identifiers.push('Qualcomm Beacon');
    identifiers.push('Progress Beacon');
    for (var i = 0; i < uuids.length; i++) {
        beaconRegion[i] = createBeacon(uuids[i], identifiers[i]);
        //alert(beaconRegion[i]);
        locationManager.locationManager.startMonitoringForRegion(beaconRegion[i]);
        //locationManager.locationManager.startRangingBeaconsInRegion(beaconRegion[i]);
        //	locationManager.locationManager.stopRangingBeaconsInRegion(beaconRegion[i]);	
    }
    setInterval(function() {
        for (var i = 0; i < uuids.length; i++) {
            //alert("123");
            locationManager.locationManager.startRangingBeaconsInRegion(beaconRegion[i]);
        }
    }, 1000);
}